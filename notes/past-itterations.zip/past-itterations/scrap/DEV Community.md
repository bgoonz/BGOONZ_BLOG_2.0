# DEV Community

> A constructive and inclusive social network for software developers. With you every step of your journey.

![Cover image for Full Stack Developer's Roadmap 🗺](https://res.cloudinary.com/practicaldev/image/fetch/s--yZ-A1RXK--/c_imagga_scale,f_auto,fl_progressive,h_420,q_auto,w_1000/https://dev-to-uploads.s3.amazonaws.com/i/s7cj5qsge61za29lvn4s.jpg)

<<<<<<< HEAD
Discussion (110)

---

=======

## Discussion (110)

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

Collapse Expand

[![anraiki profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--B2d0hIqs--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/91439/edc7bc3e-d8ad-4c32-bd74-d74563c15055.jpg)](https://dev.to/anraiki)

If you are new, and you are coming in here to see this.

I hope this isn't overwhelming to you.

Don't be discourage.

A Full-Stack Developer is more of a very long journey rather than this experience listed out here.

Collapse Expand

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 15 '20](https://dev.to/natescode/comment/16ofi)

Agreed plus "full stack" is a fancy way of companies getting someone to do two jobs for the price of one. It takes years to get good at front end or backend, let alone both

Collapse Expand

[![iamrohitsawai profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--wrghaofO--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/216432/2ff8779c-f2a5-459b-a768-f8cfcafeb152.jpg)](https://dev.to/iamrohitsawai)

[Rohit Kiran Sawai](https://dev.to/iamrohitsawai)

I work in ReactJS, ASP.NET Core, Node.JS, React JS, Wordpress

<<<<<<< HEAD

-   Location

    Beed, Maharashtra

-   education

    M. E. in Software Engineering

-   work

    Full Stack Web Developer at Ambika Recharge Solution Pvt. Ltd.

-   Joined

    Aug 22, 2019

=======

-   Location

    Beed, Maharashtra

-   education

    M. E. in Software Engineering

-   work

    Full Stack Web Developer at Ambika Recharge Solution Pvt. Ltd.

-   Joined

        Aug 22, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20 • Edited on Oct 1](https://dev.to/iamrohitsawai/comment/15gii)

I can't say I'm newbie. I have fundamental knowledge of programming. When I saw above list I came to know I know very less. Till I complete this list, complete framework will change then in what way should I be full stack developer?

Collapse Expand

[![sumit profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--9t-Bsu2H--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/446134/4cc850d2-88f5-4b65-8add-467a89af1a35.jpg)](https://dev.to/sumit)

[Sumit Singh](https://dev.to/sumit)

A code is like love ❤, it is created with clear intentions at the beginning 😍, but it can get complicated 😵

<<<<<<< HEAD

-   Email
-   Location

    Jammu & Kashmir, India

-   work

    System Engineer at TCS

-   Joined

    Aug 3, 2020

=======

-   Email
-   Location

    Jammu & Kashmir, India

-   work

    System Engineer at TCS

-   Joined

        Aug 3, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 15 '20](https://dev.to/sumit/comment/16o5f)

I think it's more about learning the fundamentals of each phase. I think that's what you have also done when started programming. Learning basic fundamentals in any language and applying it in other languages.

[![bhadresharya profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Mt7fyigy--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/202388/3b3e3573-2b04-4bab-938b-6d3386acd07c.jpg)](https://dev.to/bhadresharya)

That's right. Frameworks will come and go. but the concept stays the same. If the core concept and fundamentals are learnt well then no language or no framework will be hard to understand.

[![trangchongcheng profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--lJbv7k9P--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/373776/e255edcc-4360-4d61-bf17-662503d1a293.png)](https://dev.to/trangchongcheng)

Collapse Expand

[![aashiqincode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Hqia19O5--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/419430/73fe568a-126e-45fc-9f3b-d1b9e4e82bbd.jpeg)](https://dev.to/aashiqincode)

[Aashiq Ahmed M](https://dev.to/aashiqincode)

Frontend developer at Saama technologies

<<<<<<< HEAD

-   Location

    Trichy

-   education

    B.E Computer science

-   work

    Front-end developer at Saama technologies

-   Joined

    Jun 29, 2020

=======

-   Location

    Trichy

-   education

    B.E Computer science

-   work

    Front-end developer at Saama technologies

-   Joined

        Jun 29, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20](https://dev.to/aashiqincode/comment/15glj)

But not the core na

Collapse Expand

[![zachgoll profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--rQ7Klp1j--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/338883/8442d89a-a05e-459c-b174-cb1b3139a08a.png)](https://dev.to/zachgoll)

[Zach Gollwitzer](https://dev.to/zachgoll)

Just trying to write cleaner code each day | My story - https://youtu.be/Zr73KfbiSu0

<<<<<<< HEAD

-   Location

    Cleveland, Ohio

-   education

    Bachelor in Corporate Finance, Self Taught Dev

-   Joined

    Feb 20, 2020

=======

-   Location

    Cleveland, Ohio

-   education

    Bachelor in Corporate Finance, Self Taught Dev

-   Joined

        Feb 20, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 19 '20](https://dev.to/zachgoll/comment/17213)

Totally agree. The additional point that I would add is that this list appears as separate concepts, but if you're building a production-ready application, you'll learn 80% of this list within the scope of a single project. I don't think they are meant to be learned in isolation (although sometimes this is necessary).

Collapse Expand

[![ankitmpatel profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--1OJCqBIm--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/32222/21fd45ea-5489-4f0e-9af2-91285f1553ff.png)](https://dev.to/ankitmpatel)

[Ankit Patel](https://dev.to/ankitmpatel)

Full Stack Developer - System Architect - Agile Developer

<<<<<<< HEAD

-   Email
-   Location

    India

-   Joined

    Sep 4, 2017

=======

-   Email
-   Location

    India

-   Joined

        Sep 4, 2017

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20](https://dev.to/ankitmpatel/comment/15gff)

Agreed!! That's why the roadmap requires achieving a long journey. I guess the author tries to convey!!

Collapse Expand

[![hyperx837 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--BLOBskUY--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/400766/fcebed9c-f539-4d09-9d4b-694fc37f3962.png)](https://dev.to/hyperx837)

[Hyper](https://dev.to/hyperx837)

trying to learn more

<<<<<<< HEAD

-   Location

    EveryWhere

-   Joined

    Jun 2, 2020

=======

-   Location

    EveryWhere

-   Joined

        Jun 2, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 9 '20](https://dev.to/hyperx837/comment/16i22)

just following these things and "diving deep" into this topics will complete that long journey

Collapse Expand

[![ajax27 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--FLoYrrmG--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/77713/0ae6b5ee-9e38-4c95-a33e-2f1d3b0f0454.jpeg)](https://dev.to/ajax27)

[Shaun Collins](https://dev.to/ajax27)

After a long military career, I decided on a new path, something more productive. So three years ago I bought my first laptop. Since then I have I have built countless websites and several apps.

<<<<<<< HEAD

-   Location

    United Kingdom

-   education

    Easthampstead Park Comprehensive

-   work

    Freelance at Self Employed

-   Joined

    Jun 9, 2018

=======

-   Location

    United Kingdom

-   education

    Easthampstead Park Comprehensive

-   work

    Freelance at Self Employed

-   Joined

        Jun 9, 2018

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Sep 30 '20](https://dev.to/ajax27/comment/15g11)

Totally agree!

Collapse Expand

[![dualyticalchemy profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Q6sPoH92--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/375538/4a9566d0-65cc-453c-bf48-70eb6e9168cf.jpg)](https://dev.to/dualyticalchemy)

Collapse Expand

[![siy profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--93PwCobS--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/145374/6e93547b-45cc-430e-9659-3adea03266b5.jpeg)](https://dev.to/siy)

[Sergiy Yevtushenko](https://dev.to/siy)

Writing code for 30+ years and still enjoy it...

<<<<<<< HEAD

-   Location

    Krakow, Poland

-   work

    Senior Software Architect

-   Joined

    Mar 14, 2019

=======

-   Location

    Krakow, Poland

-   work

    Senior Software Architect

-   Joined

        Mar 14, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 12 '20](https://dev.to/siy/comment/16l0l)

Suggestion to use microservices is not very good one. This is an expensive step and in most cases organizations are not prepared for them.

Collapse Expand

[![dualyticalchemy profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Q6sPoH92--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/375538/4a9566d0-65cc-453c-bf48-70eb6e9168cf.jpg)](https://dev.to/dualyticalchemy)

i didn't suggest to use microservices. i saw that someone else mentioned it, and i supplied links to tools and ideas that makes microservices easier to achieve. i listed tools relevant to microservices; i did not suggest that one choose microservices over some other SOA or style irrespective to their problem or economic situation

if anything, a more intuitive reading of my post would be: "IF you use microservices, use scale cube and microservice design canvas", not "HEY USE MICROSERVICE NOW"

notice, all I did was mention the word "microservice" and two things. just because someone puts it on the road map doesn't mean it's a suggested path, but that it is a suggestion of an _opportunity_ to take a path.

this discussion is about what _we_ can learn as developers in order to be competitive and knowledgeable given the problem set, regardless of the budget to achieve it. we're not here to figure out one organization's problem _as_ individual developers. microservices is one of many things we're expected to understand and learn. we're not asking "what is the road map if you have budget X for organization Y", we're just asking what the road map is. you're bringing it a lot of other background or contextual information to a discussion that doesn't depend on it

Collapse Expand

[![dualyticalchemy profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Q6sPoH92--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/375538/4a9566d0-65cc-453c-bf48-70eb6e9168cf.jpg)](https://dev.to/dualyticalchemy)

oh you mention docker; use lazydocker. also: percol, ranger, ack, ... all available through homebrew. pryjs is helpful too

Collapse Expand

[![ender_minyard profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kvTuvHXf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/371085/f90a0a30-61da-4640-a98d-37ec5bf2bc61.png)](https://dev.to/ender_minyard)

Collapse Expand

[![alamba78 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--VjYdv6Ht--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/146470/8b758268-4a58-448c-a807-f973b3db009d.png)](https://dev.to/alamba78)

[Amit Lamba](https://dev.to/alamba78)

Polyglot programmer now focusing on Elixir/Phoenix FP

<<<<<<< HEAD

-   Location

    Plant City, FL

-   work

    Fullstack developer

-   Joined

    Mar 17, 2019

=======

-   Location

    Plant City, FL

-   work

    Fullstack developer

-   Joined

        Mar 17, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20](https://dev.to/alamba78/comment/15i0l)

Python 3 would be a fundamental language to learn before even JS, Rust, and Go.

Collapse Expand

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 15 '20](https://dev.to/natescode/comment/16ofb)

Before JavaScript? Not if one plans on touching the web at all. Go and Rust are up-and-coming but not big yet.

Collapse Expand

[![alamba78 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--VjYdv6Ht--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/146470/8b758268-4a58-448c-a807-f973b3db009d.png)](https://dev.to/alamba78)

The article is about fullstack roadmap. A person new to programming would only get tripped up with JS's quirks, if they truly want to learn JS and not a framework or library. Python will be better to learn OO, and with that foundation someone can tackle the idiosyncrasies (prototypal inheritance) of JS. I would never wish for my enemy to come into programming with JS as their first language. Better to get an early win with Python or even Java. It's not a race.

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 16 '20](https://dev.to/natescode/comment/16p0g)

No JS = no full stack job. You're gonna use Python for front end? Don't think so. JS is required like it or not. You can't have a roadmap of skills that leaves out the only native language to the front end. No front end frameworks and no big backend languages like Java and C#.  
To each their own. But if you have all the skills listed you'll never get a full stack job without JavaScript + react and C# / Java.

[![alamba78 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--VjYdv6Ht--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/146470/8b758268-4a58-448c-a807-f973b3db009d.png)](https://dev.to/alamba78)

[Amit Lamba](https://dev.to/alamba78)

Polyglot programmer now focusing on Elixir/Phoenix FP

<<<<<<< HEAD

-   Location

    Plant City, FL

-   work

    Fullstack developer

-   Joined

    Mar 17, 2019

=======

-   Location

    Plant City, FL

-   work

    Fullstack developer

-   Joined

        Mar 17, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 16 '20](https://dev.to/alamba78/comment/16p59)

You seem to be looking for an argument. I never said don't learn JS. It's the order of learning I'm talking about. JS first, in my opinion, will lead people new to programming down a whole lot of hurt. I think you should re-read what I said without your bias. JS is fantastic and crucial, in time, for a new programmer.

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 16 '20](https://dev.to/natescode/comment/16p5a)

Nope, no argument here. Just options. Thanks for the clarification. It's a great roadmap

[![savagepixie profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--2jZ_IQs8--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/200345/2e5002ed-8500-43ee-acad-5e687bbe7f48.png)](https://dev.to/savagepixie)

> JS first, in my opinion, will lead people new to programming down a whole lot of hurt.

On the other hand, people who start with JavaScript won't try to write JavaScript as if it were another programming language and get frustrated because it doesn't work like their favourite language does. Neither will they learn only one programming paradigm like OOP because it's the only one their language supports and then try to impose it to every other language they learn.

Also, JavaScript is a very nice language to start with because you can very quickly see fancy things happening (like a webpage reacting to user clicks and all that), as opposed to just printing stuff on the console.

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 19 '20](https://dev.to/natescode/comment/1720e)

I agree. In some ways it's a good first language: no install needed, visual feedback, tons of resources etc. but in others it isn't: dynamically typed, quirks, prototypal, weird type system etc.

One definitely needs statically typed OOP languages like C# or Java to get the fundamentals down. Too many wannabes hate on statically typed languages because they're "hard".

Either way, if one's gonna be a full stack Dev then they have to learn JS, or you're by definition not full-stack which is my argument on the whole roadmap.

Collapse Expand

[![cjcon90 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--d5BbvHjv--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/396225/0ec7ac75-7368-464b-8ff1-e325a7b649f5.jpg)](https://dev.to/cjcon90)

[Ciaran Concannon](https://dev.to/cjcon90)

I'm a full time child protection social worker, aiming to make the transition into development! Wrote my first 'Hello World' in April 2020 and currently learning to be a MEVN stack developer

<<<<<<< HEAD

-   Email
-   Location

    Ireland

-   Joined

    May 27, 2020

=======

-   Email
-   Location

    Ireland

-   Joined

        May 27, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 2 '20](https://dev.to/cjcon90/comment/15ij9)

I've only just started learning python for the purposes of backend skills in the near future, glad to see this comment here! 😋

Collapse Expand

[![jep profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--A2c7sJe5--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/90644/1798e430-b3d8-4dc6-b53c-1ebef3b58d34.png)](https://dev.to/jep)

[Jim](https://dev.to/jep)

Husband and Dad 👨‍👩‍👧‍👦 DevOps Engineer 🛠️🤖🤘🏼 Geek 🕹️and Hobbyist coder 👨🏻‍💻🔰 Always longing for the Internet of the 90s 💾 I 💜 Python 🐍, learning JS/Node. 🤞

<<<<<<< HEAD

-   Location

    DMV, US

-   work

    DevOps Engineer

-   Joined

    Aug 8, 2018

=======

-   Location

    DMV, US

-   work

    DevOps Engineer

-   Joined

        Aug 8, 2018

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Sep 30 '20](https://dev.to/jep/comment/15fl1)

Excellent list. For the benefit of other folks who may be working in a company that uses different technologies for different groups, I recommend adding some information about Subversion (SVN) under **Version Control**. I was so used to git, but hadn't ever used SVN and it took some time to get out of the Git mindset.

<<<<<<< HEAD
There are two posts on DEV that may be of use :

=======
There are two posts on DEV that may be of use :

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

Collapse Expand

[![ender_minyard profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kvTuvHXf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/371085/f90a0a30-61da-4640-a98d-37ec5bf2bc61.png)](https://dev.to/ender_minyard)

Collapse Expand

[![pawelowczarekfalcon profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--8icJWBoO--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/63734/c2318b3e-6490-4dea-b618-d26e8b4e5b3e.png)](https://dev.to/pawelowczarekfalcon)

Nice article, thanks :) ... but there is nothing about Frameworks. They are very important. Full-Stack Dev should know Spring Boot (JAVA) and Symfony (PHP) for creating REST APIs and Angular or React for Front End development. There is many topics covered which are less important than frameworks, that needed in work ;-).

Collapse Expand

[![lbeul profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--myDiDu2Q--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/197371/919b7724-4567-4cde-affc-3d91b2e179a5.jpg)](https://dev.to/lbeul)

[Louis](https://dev.to/lbeul)

23-year-old student from Germany who fell in love with coding and the tech industry after pivoting from a traditional career in banking.Currently pursuing a Bachelor's in CompSci.

<<<<<<< HEAD

-   Location

    Bamberg, Germany

-   education

    Studying "Software Systems Science (BSc)" in Bamberg, Germany

-   work

    Computer Science Student

-   Joined

    Jul 18, 2019

=======

-   Location

    Bamberg, Germany

-   education

    Studying "Software Systems Science (BSc)" in Bamberg, Germany

-   work

    Computer Science Student

-   Joined

        Jul 18, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 10 '20 • Edited on Oct 10](https://dev.to/lbeul/comment/16jp0)

I totally get your point, Paweł. From the _Employability_ Aspect, it makes a lot of sense to focus on the latest frameworks and libraries. However - as a learning roadmap - the goal of this article may be to focus on teaching you the underlying concepts and principles modern web apps rely on. I think if you got this essential knowledge and understand what goes on "under the hood", it'll be easy for you to pick up new languages & frameworks.

Collapse Expand

[![allestri profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--ZSScNK1j--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/467124/ac5586de-5428-419b-9017-2e70c988ca7c.jpeg)](https://dev.to/allestri)

[Allestri](https://dev.to/allestri)

Ship it when it's ready.

<<<<<<< HEAD

-   Location

    Breizh

-   work

    Day Dreamer

-   Joined

    Sep 10, 2020

=======

-   Location

    Breizh

-   work

    Day Dreamer

-   Joined

        Sep 10, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20](https://dev.to/allestri/comment/15h0g)

Not only Symfony but Slim is also great for creating simple API, as it names suggests, Slim is lightweight.  
Design patterns such as MVC or ADR which the creator of Slim embraces ( I personally don't like it tho ) could be a plus.

Collapse Expand

[![dabjazz profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--knAn1RTf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/452946/2d9eca41-973e-4a65-b4f4-24a55bc2c5bf.jpeg)](https://dev.to/dabjazz)

<<<<<<< HEAD
[Yash_Jaiswal](https://dev.to/dabjazz)

I'm a 3rd year IT(ISE) student exploring various tech-field. I am currently learning flutter & starting cloud computing.

-   Location

    India

-   work

    Student at Still un-employed but will start working as a freelancer.

-   Joined

    Aug 15, 2020

=======
[Yash_Jaiswal](https://dev.to/dabjazz)

I'm a 3rd year IT(ISE) student exploring various tech-field. I am currently learning flutter & starting cloud computing.

-   Location

    India

-   work

    Student at Still un-employed but will start working as a freelancer.

-   Joined

        Aug 15, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 7 '20](https://dev.to/dabjazz/comment/16ge6)

I've got the java developer roadmap  
Core java(basic concepts, oops, collection framework, stream api)->advance java (servlets,JSP,JDBC)->build tool(maven/gradle)->framework (Spring/hibernate/play/grails etc)

Collapse Expand

[![melvinkim profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--QwDfme_3--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/613234/f4a596a2-30d5-471b-a6ba-a5dcae4322ea.png)](https://dev.to/melvinkim)

Hey, could you share the Java roadmap

Collapse Expand

[![scroung720 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--4e9RxAfo--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/444597/64d133c0-430c-4294-9b0c-4fc57c3fc694.jpg)](https://dev.to/scroung720)

Collapse Expand

[![ender_minyard profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kvTuvHXf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/371085/f90a0a30-61da-4640-a98d-37ec5bf2bc61.png)](https://dev.to/ender_minyard)

Collapse Expand

[![bunda3d profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--eL8dz_nS--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/107452/d0b021cd-1713-4bc5-9a2d-d2472d6bb96e.png)](https://dev.to/bunda3d)

I didn't see much on a major corporate tech stack: Microsoft-backed .NET frameworks, SQL Server, and their server architecture (IIS).

There's also not much on what I consider the nexus point, common ground, equalizer, or uniter of the front and backend dev: the IDE. And to tie it back to MS, IMO, they provide the 2 best IDEs in the business: Visual Studio and VS Code. The IDE is where I spend 80 percent of my time as a full stack developer, along with browsers (using dev tools for troubleshooting and researching the internet--I consider the browser as part of the Integrated Development Environment, at least in practice).

It's not to be an exhaustive list of specifics, I know, but here's my comments on specific categories I saw missing the Microsoft platforms I'm used to learning about/using as a full stack dev, FWIW. (I also live in an Apache /Angular / PHP / MySQL world, and saw more about those stacks on the list, which is fair).

Good list of concepts and technologies to be aware of in some degree as a FSD.

Collapse Expand

[![shaijut profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--_dIQIaqe--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/299467/ee6d3aaa-65ce-43b8-9f3c-af4412777eef.png)](https://dev.to/shaijut)

[Shaiju T](https://dev.to/shaijut)

I am a Full stack .NET Developer, I like to work with C#, Asp.Net Core, SQL, Mongo DB, Azure, JavaScript... Always eager to learn new technologies. I am here to share, ask & eventually learn.

<<<<<<< HEAD

-   Location

    India

-   education

    MSC SE

-   work

    Software Engineer

-   Joined

    Dec 23, 2019

=======

-   Location

    India

-   education

    MSC SE

-   work

    Software Engineer

-   Joined

        Dec 23, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20 • Edited on Oct 27](https://dev.to/shaijut/comment/15hd1)

Nice , 😄, Add `Java` and `C#` in languages , it is used by big companies and enterprise, both languages have more Job opportunities. Also add `Design Patterns` in Development Concepts.

Collapse Expand

[![sandorturanszky profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--2rnmaujK--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/94890/249148c3-2788-4626-b935-f6f46bdb0405.jpeg)](https://dev.to/sandorturanszky)

[SandorTuranszky](https://dev.to/sandorturanszky)

I dig into web tech, document my learning journey in plain English and blog about it!

<<<<<<< HEAD

-   Email
-   Location

    Malta

-   work

    I am mentoring beginner web developers and running a tech newsletter at https://tutorialhell.substack.com/subscribe

-   Joined

    Aug 22, 2018

=======

-   Email
-   Location

    Malta

-   work

    I am mentoring beginner web developers and running a tech newsletter at https://tutorialhell.substack.com/subscribe

-   Joined

        Aug 22, 2018

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 9 '20](https://dev.to/sandorturanszky/comment/16i5d)

You need to now what's availble, but focus on Front-end or Backend. Unless you use JavaScript, of course. In this case you can be more or less proficient in the client and server tech.

The best is to learn concepts and patterns. The rest are tools that come and go. If you know a programming language, you will figure our any framework or lib written with it. If you know what databases are, what are the core principles, how they work and what they are for (SQL, NoSQL, Graph), you will figure out MySQL, PostgresQL, Mongo, etc.

With this knowledge you will be always uptodate.

Collapse Expand

[![andrewbaisden profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--RWdBOJwA--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/333889/005fe9de-759e-4d70-9c3c-d3aa1289b2ef.png)](https://dev.to/andrewbaisden)

[Andrew Baisden](https://dev.to/andrewbaisden)

<<<<<<< HEAD
👨🏿‍💻 Software Developer @CGI_Global 🖼 Content Creator. Sharing the mindset and content so you work hard to grow stronger than your past self ☯️

-   Location

    London, UK

-   education

    Bachelor Degree Computer Science

-   work

    Full-Stack Developer at Freelance

-   Joined

    Feb 11, 2020

=======
👨🏿‍💻 Software Developer @CGI_Global 🖼 Content Creator. Sharing the mindset and content so you work hard to grow stronger than your past self ☯️

-   Location

    London, UK

-   education

    Bachelor Degree Computer Science

-   work

    Full-Stack Developer at Freelance

-   Joined

        Feb 11, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 4 '20](https://dev.to/andrewbaisden/comment/15nlh)

Cool list missing the frameworks though like React, Angular and Vue. Also there are much more languages than that some readers might think that you have to learn all of them. When in reality you can specialise with certain technical stacks like React/Node, React/Flask etc... Also you did not mention Python as a language which has more popularity than PHP and Ruby. Choice is good better to cover them all.

Collapse Expand

[![ptprashanttripathi profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kHJ4FX_v--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/430585/03d89758-3dc2-41de-a943-f65cd2ca7d3c.jpg)](https://dev.to/ptprashanttripathi)

[Pt. Prashant tripathi](https://dev.to/ptprashanttripathi)

Programmer • Developer • learner Although A computer science engineer working with DevOps tools and looking forward to Share and Gain knowledgeable stuff. Experience Level: 6+ years

<<<<<<< HEAD

-   Location

    Jabalpur, India

-   education

    B.E. in CSE

-   work

    System Engineer at TATA consultancy services

-   Joined

    Jul 13, 2020

• [Oct 15 '20 • Edited on Oct 15](https://dev.to/ptprashanttripathi/comment/16ome)

# Hi, I'm a newbie I have learned

-   Location

    Jabalpur, India

-   education

    B.E. in CSE

-   work

    System Engineer at TATA consultancy services

-   Joined

    Jul 13, 2020

• [Oct 15 '20 • Edited on Oct 15](https://dev.to/ptprashanttripathi/comment/16ome)

Hi, I'm a newbie I have learned

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

    {
      "web-development":{
        "front-end":["html","css","js(amature)"],
        "back-end":{
          "language":"php",
          "database":"mysql"
        }
      },
      "additional":["git","markdown"]
      }

<<<<<<< HEAD

=======

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

Enter fullscreen mode Exit fullscreen mode

**I have made some small projects in past**  
What should I learn next

Collapse Expand

[![dabjazz profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--knAn1RTf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/452946/2d9eca41-973e-4a65-b4f4-24a55bc2c5bf.jpeg)](https://dev.to/dabjazz)

<<<<<<< HEAD
[Yash_Jaiswal](https://dev.to/dabjazz)

I'm a 3rd year IT(ISE) student exploring various tech-field. I am currently learning flutter & starting cloud computing.

-   Location

    India

-   work

    Student at Still un-employed but will start working as a freelancer.

-   Joined

    Aug 15, 2020

=======
[Yash_Jaiswal](https://dev.to/dabjazz)

I'm a 3rd year IT(ISE) student exploring various tech-field. I am currently learning flutter & starting cloud computing.

-   Location

    India

-   work

    Student at Still un-employed but will start working as a freelancer.

-   Joined

        Aug 15, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 3 '20](https://dev.to/dabjazz/comment/15kd0)

Just How long it will take to complete this journey? I'm in third (pre-final year) of my engineering and I'm about to start my journey in development. I still couldn't decide whether to opt for android development or web development.

Collapse Expand

[![ender_minyard profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kvTuvHXf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/371085/f90a0a30-61da-4640-a98d-37ec5bf2bc61.png)](https://dev.to/ender_minyard)

Learning is the point.

Learning how to learn is the most important skill you can practice. You will never stop learning. There will always be something new. The point is to enjoy the process of learning.

Collapse Expand

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 15 '20](https://dev.to/natescode/comment/16ofe)

I have 8 years industry experience and I haven't finished this list. One just has to be capable of learning to survive in the field.

Collapse Expand

[![stojakovic99 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--umapzuf8--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/100790/1e062bff-fab2-4411-9add-272f39330afc.jpg)](https://dev.to/stojakovic99)

[Nikola Stojaković](https://dev.to/stojakovic99)

Software developer who loves philosophy and animals.

<<<<<<< HEAD

-   Location

    Serbia

-   education

    Electrical engineer of multimedia

-   work

    Software developer at Inviggo

-   Joined

    Sep 12, 2018

=======

-   Location

    Serbia

-   education

    Electrical engineer of multimedia

-   work

    Software developer at Inviggo

-   Joined

        Sep 12, 2018

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [May 16](https://dev.to/stojakovic99/comment/1egfk)

For those who are still coming to this post - don't use Rust by Example if you're a beginner. Start with the [Rust book](https://doc.rust-lang.org/book/). Also, keep in mind that Rust is quite hard for beginner developers and there are not much jobs in it right now for juniors.

Collapse Expand

[![tnharvey profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--hTJ30j9a--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/132176/5da630a4-9f9e-4fd5-8731-0b1f23d44aca.jpeg)](https://dev.to/tnharvey)

This this this! I've seen so many "full stack roadmaps" that did exactly what the other roadmap you referenced did, and left me wanting more specifics. What newcomers will benefit most from is hearing from experienced coders which specific resources are most valuable, and how those fit into the bigger pitcture, which this does. Thanks!

Collapse Expand

[![anja profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--ok0R7oF4--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/486610/77b48738-6ca1-442e-bcf9-05c933d58944.jpeg)](https://dev.to/anja)

[Anja](https://dev.to/anja)

Software Engineer | Linux fan | lawyer | Sharing what I'm learning 😊

• [Oct 10 '20](https://dev.to/anja/comment/16jeo)

Brilliant thanks for this! 😊

Collapse Expand

[![devdev606 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--J3rJpiru--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/470730/fe456d51-7c49-450d-af90-ee5d4556d187.jpg)](https://dev.to/devdev606)

[Huntr.dev](https://dev.to/devdev606)

I will learning too harder and never give up....

<<<<<<< HEAD

-   Email
-   Joined

    Sep 17, 2020

=======

-   Email
-   Joined

        Sep 17, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 10 '20](https://dev.to/devdev606/comment/16jp3)

Thanks you.. successful for u.. GBU

Collapse Expand

[![mdalaminroni22 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--VitFUPHk--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/607474/c9937eb5-d31a-4bc2-859f-d98f2fb8516c.png)](https://dev.to/mdalaminroni22)

Collapse Expand

[![amboulouma profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--T8JSUjBm--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/654512/16e7376c-c4d2-4f32-8f5b-5b4c028a51d1.jpeg)](https://dev.to/amboulouma)

[Amin M. Boulouma](https://dev.to/amboulouma)

I build things for fun.

<<<<<<< HEAD

-   Location

    Vienna, Austria

-   education

    M.Sc, M.Eng, Computer Science, Business Informatics

-   work

    Software Engineer at Freelance

-   Joined

    Jun 23, 2021

=======

-   Location

    Vienna, Austria

-   education

    M.Sc, M.Eng, Computer Science, Business Informatics

-   work

    Software Engineer at Freelance

-   Joined

        Jun 23, 2021

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Jun 27](https://dev.to/amboulouma/comment/1fmdl)

Collapse Expand

[![domis66 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--eLcTqZfH--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/140171/3f5a55f5-8f2c-4896-8a01-11abc701ad1d.jpeg)](https://dev.to/domis66)

[Dominique Péré](https://dev.to/domis66)

Software Engineer, then father, then CTO, then father again, then cofounder, then CEO, then MBA, then success, then crash, then freelance and then CMO at @scaledynamics

<<<<<<< HEAD

-   Location

    France

-   education

    IT Engineer Master degree, executive MBA

-   work

    CMO at ScaleDynamics

-   Joined

    Feb 25, 2019

• [Oct 3 '20 • Edited on Oct 3](https://dev.to/domis66/comment/15jep)

# Awesome list! And so realize today it's way harder to become a fullstack developer it used to be.... You might want to consider some platforms helping you down that road, just like ScaleDynamics

-   Location

    France

-   education

    IT Engineer Master degree, executive MBA

-   work

    CMO at ScaleDynamics

-   Joined

    Feb 25, 2019

• [Oct 3 '20 • Edited on Oct 3](https://dev.to/domis66/comment/15jep)

Awesome list! And so realize today it's way harder to become a fullstack developer it used to be.... You might want to consider some platforms helping you down that road, just like ScaleDynamics

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

It turns a simple JS modules into a hosted back end and a client wrapper). Work smarter, not harder ;)

Collapse Expand

[![swathipai13 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--YCAK1ISl--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/379821/cd2de714-9385-411f-954f-392d9259b509.jpg)](https://dev.to/swathipai13)

<<<<<<< HEAD
[miss_multitasker](https://dev.to/swathipai13)

I am a beginner at Javascript for desktop applications, open source enthusiast and evangelist!

-   Location

    India

-   work

    Engineer at Self employed

-   Joined

    May 5, 2020

=======
[miss_multitasker](https://dev.to/swathipai13)

I am a beginner at Javascript for desktop applications, open source enthusiast and evangelist!

-   Location

    India

-   work

    Engineer at Self employed

-   Joined

        May 5, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Dec 20 '20](https://dev.to/swathipai13/comment/19d66)

I started crying after reading this list. Firstly because I was getting a grip over node and react, juggling with python and Javascript. I always thought for myself, these would be something industries use and would help me make many projects, and also land in a descent job. Guess it would take time for me to do anything in life!

Collapse Expand

[![ender_minyard profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--kvTuvHXf--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/371085/f90a0a30-61da-4640-a98d-37ec5bf2bc61.png)](https://dev.to/ender_minyard)

Consider this a lifelong reading list, not a to-do list. Take your time.

It will not "take time" for you "to do anything in life". Every day that you wake up and get out of bed, you're doing something. Brushing your teeth and making your bed is an accomplishment, especially during the times we're living in. Please be kind to yourself.

Collapse Expand

[![farukbigez profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--SC3vceD3--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/397332/bd3dbf63-0ff8-474f-8dc5-335d76d97f39.jpeg)](https://dev.to/farukbigez)

[farukbigez](https://dev.to/farukbigez)

Hype-Driven Developer

<<<<<<< HEAD

-   Email
-   Location

    Istanbul

-   work

    Full-Stack

-   Joined

    May 28, 2020

=======

-   Email
-   Location

    Istanbul

-   work

    Full-Stack

-   Joined

        May 28, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 1 '20](https://dev.to/farukbigez/comment/15i0i)

really good roadmap. Followers of this roadmap keep this in your mind: this is an adventure not a race or mission that needs to be completed

Collapse Expand

[![kisore99 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--ZrQdVV8b--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/424364/514173ca-5d0f-4de7-82f0-75937224e8cc.jpeg)](https://dev.to/kisore99)

Collapse Expand

[![kevinlalkalathingal profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Cd8rb8WH--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/485638/33a39f88-82cc-4837-8476-eb88314ff32a.png)](https://dev.to/kevinlalkalathingal)

Thank you for this post. I'm new here and now i know that there's a lot more to learn.

Collapse Expand

[![nocnica profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--H5l0kE5u--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/162459/8d0dc115-8aac-4a0f-8bc0-7e7c597aef12.jpg)](https://dev.to/nocnica)

[Nočnica Fee](https://dev.to/nocnica)

Actually the pug from Dune (1984)

<<<<<<< HEAD

-   Location

    Portland, Oregon

-   work

    Developer Advocate at New Relic

-   Joined

    Apr 30, 2019

=======

-   Location

    Portland, Oregon

-   work

    Developer Advocate at New Relic

-   Joined

        Apr 30, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 9 '20](https://dev.to/nocnica/comment/16ipk)

Welcome! Thanks for bringing the positivity

Collapse Expand

[![iaryan profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--wlHl2FqC--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/479594/8e4d6f4d-b767-4f54-b1eb-1cce24ee75c6.jpeg)](https://dev.to/iaryan)

[Aryan Verma](https://dev.to/iaryan)

Hey, I'm an undergrad majoring in Electronics with minor in CS. I do WebDev projects these days in JavaScript (occasionally Django).

<<<<<<< HEAD

-   Location

    India

-   education

    Electronics with Minor CS, IIT Guwahati

-   Joined

    Oct 1, 2020

=======

-   Location

    India

-   education

    Electronics with Minor CS, IIT Guwahati

-   Joined

        Oct 1, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 10 '20](https://dev.to/iaryan/comment/16j9a)

Thanks a ton! This has got to be one of the best web dev source compilations!

Collapse Expand

[![rahulh123 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aftXc32Q--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/486902/31dbb3c7-d258-486b-8da9-ba4ffbfb2561.png)](https://dev.to/rahulh123)

[Rahul](https://dev.to/rahulh123)

just doing stuff

<<<<<<< HEAD

-   Location

    Chicago

-   work

    Game Developer

-   Joined

    Oct 10, 2020

=======

-   Location

    Chicago

-   work

    Game Developer

-   Joined

        Oct 10, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 11 '20](https://dev.to/rahulh123/comment/16kdc)

Wow! This is incredible! I think this is the kinda stuff that makes self-learning easier. It's like a curriculum. Thank you so much for this resource, I am sure you helped a lot of developers.

Collapse Expand

[![fluxthedev profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--dPmT3j9a--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/377899/c62b46e6-d3ad-4741-a4a1-29ee3443b9f3.jpeg)](https://dev.to/fluxthedev)

[John](https://dev.to/fluxthedev)

Hello! John here 27 7 and have been active in my web developer career for 6 years and enjoy most bits :)

<<<<<<< HEAD

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

    May 2, 2020

=======

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

        May 2, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 6 '20](https://dev.to/fluxthedev/comment/168m4)

Nice road map! Senior-ish web developer here looking to go full stack. Curious, why do you have Rust and Go? Do I really need to learn both?

Collapse Expand

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 19 '20](https://dev.to/natescode/comment/1720n)

Nope. Pick C# or Java. That's what companies use. Ignore Go and Rust; no jobs for them. Spring Boot for Java or .NET core MVC and you're set.

Collapse Expand

[![fluxthedev profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--dPmT3j9a--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/377899/c62b46e6-d3ad-4741-a4a1-29ee3443b9f3.jpeg)](https://dev.to/fluxthedev)

[John](https://dev.to/fluxthedev)

Hello! John here 27 7 and have been active in my web developer career for 6 years and enjoy most bits :)

<<<<<<< HEAD

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

    May 2, 2020

=======

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

        May 2, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 19 '20](https://dev.to/fluxthedev/comment/17226)

Actually when I worked for nationwide, alot of teams were using go for a Middleware between front end and back end/apps. Wendy's also (unless they changed it in the last 3 years) uses go for their pos system

[![natescode profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--aVXV5o0W--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/209667/cc0ea3f4-acdd-4e9f-aa8e-aa21e8392596.jpeg)](https://dev.to/natescode)

[Nate](https://dev.to/natescode)

I'm a Midwest-based Software Engineer.

<<<<<<< HEAD

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

    Aug 9, 2019

=======

-   Location

    Minneapolis, MN

-   education

    AAS

-   work

    Software Engineer at Barings LLC

-   Joined

        Aug 9, 2019

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 19 '20](https://dev.to/natescode/comment/1722a)

Cool! I'd love to do Go professionally.

[![fluxthedev profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--dPmT3j9a--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/377899/c62b46e6-d3ad-4741-a4a1-29ee3443b9f3.jpeg)](https://dev.to/fluxthedev)

[John](https://dev.to/fluxthedev)

Hello! John here 27 7 and have been active in my web developer career for 6 years and enjoy most bits :)

<<<<<<< HEAD

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

    May 2, 2020

=======

-   Location

    Columbus, Ohio

-   education

    Bachelors in Multimedia Design and Development

-   work

    Application developer at Nationwide Insurance

-   Joined

        May 2, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 22 '20](https://dev.to/fluxthedev/comment/17549)

Yeah it seems to be kicking off! Find a use for it where you are and make a case for it!

Collapse Expand

[![devhammed profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--epA2xY_3--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/54546/7e6f5eae-843c-43eb-ac03-ca2a3c99acb4.png)](https://dev.to/devhammed)

[Hammed Oyedele](https://dev.to/devhammed)

An experienced software developer with a strong background in developing award-winning web and mobile applications for diverse clients with 4+ years of industry experience.

<<<<<<< HEAD

-   Email
-   Location

    Ibadan, Nigeria

-   work

    Chief Technology Officer at Epower.ng

-   Joined

    Jan 20, 2018

=======

-   Email
-   Location

    Ibadan, Nigeria

-   work

    Chief Technology Officer at Epower.ng

-   Joined

        Jan 20, 2018

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 21 '20](https://dev.to/devhammed/comment/1736f)

How will I be able to know all these when the government of where I live "Nigeria" is killing techies!

Collapse Expand

[![mmoallemi99 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--q8OaJfLp--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/483903/22395aba-831b-4563-8c69-e71c9b8f6c7c.jpeg)](https://dev.to/mmoallemi99)

Collapse Expand

[![z00md profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--Sk1iOE7C--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/328222/e7903ced-d3b5-4064-ab3f-1fa03b2d99f4.png)](https://dev.to/z00md)

[z00md](https://dev.to/z00md)

Developer. Artist. Human.

<<<<<<< HEAD

-   Location

    India

-   work

    Software Engineer

-   Joined

    Feb 1, 2020

=======

-   Location

    India

-   work

    Software Engineer

-   Joined

        Feb 1, 2020

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Oct 12 '20](https://dev.to/z00md/comment/16len)

Good collection. Adding to my reading list. But I wont categorize this as Full Stack dev guide. In fact every topic itself is so big that you could find a full time job for each one of them. At once it felt like I am checking out the syllabus for a 3 year course.

Collapse Expand

[![javinpaul profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--WI-H90_U--/c_fill,f_auto,fl_progressive,h_50,q_66,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/101616/c488dc69-7dca-4855-b291-3711ce5ac7da.gif)](https://dev.to/javinpaul)

Collapse Expand

[![tayyabtariq242 profile image](https://res.cloudinary.com/practicaldev/image/fetch/s--FI0IOy_4--/c_fill,f_auto,fl_progressive,h_50,q_auto,w_50/https://dev-to-uploads.s3.amazonaws.com/uploads/user/profile_image/577570/699497c4-2f50-436e-b039-d55b4dc4120c.jpeg)](https://dev.to/tayyabtariq242)

[Muhammad Tayyab Tariq](https://dev.to/tayyabtariq242)

I am passionate to learn new Technologies

<<<<<<< HEAD

-   Email
-   Location

    Pakistan

-   education

    Masters in Information Technology

-   work

    Lab Engineer at RIUF

-   Joined

    Feb 11, 2021

=======

-   Email
-   Location

    Pakistan

-   education

    Masters in Information Technology

-   work

    Lab Engineer at RIUF

-   Joined

        Feb 11, 2021

    > > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4

• [Feb 12](https://dev.to/tayyabtariq242/comment/1bcf7)

great

<<<<<<< HEAD

# [Source](https://dev.to/ender_minyard/full-stack-developer-s-roadmap-2k12)

[Source](https://dev.to/ender_minyard/full-stack-developer-s-roadmap-2k12)

> > > > > > > bed43c0156f1c7fa6aedd1d8e3c3ff5c475148e4
