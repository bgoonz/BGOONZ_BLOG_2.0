https://hackmd.io/@bgoonz/ByOco9_yY#Review-Of-Previous-Concepts
