window.onGatsbyRouteUpdate = function() {
window.addMainNavigationHandlers();
window.addDocsNavigationHandlers();
window.addPageNavLinks();
};